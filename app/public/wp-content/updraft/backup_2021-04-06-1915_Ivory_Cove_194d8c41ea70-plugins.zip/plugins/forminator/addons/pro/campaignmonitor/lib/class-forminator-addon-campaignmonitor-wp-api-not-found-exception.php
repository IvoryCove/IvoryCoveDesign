<?php

/**
 * Class Forminator_Addon_Campaignmonitor_Wp_Api_Not_Found_Exception
 * Exception holder for campaignmonitor wp api on 404 not found error status
 *
 * @since 1.0 Campaignmonitor Addon
 */
class Forminator_Addon_Campaignmonitor_Wp_Api_Not_Found_Exception extends Forminator_Addon_Campaignmonitor_Wp_Api_Exception {
}
