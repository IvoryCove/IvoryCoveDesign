var $dev = jQuery('<style id="dev-css"></style>');
jQuery('body').append($dev);
