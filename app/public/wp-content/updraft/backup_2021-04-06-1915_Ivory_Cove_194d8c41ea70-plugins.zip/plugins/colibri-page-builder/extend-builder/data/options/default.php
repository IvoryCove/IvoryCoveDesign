<?php

namespace ExtendBuilder;

class ColibriOptionsIds {
    const RULES = 'sheet_rules';
    const CSS_BY_RULE_ID = 'css_by_rule_id';
    const CSS_BY_PARTIAL_ID = 'css_by_partials_id';
    const GLOBAL_CSS = 'global_css';
}
