<?php get_header(); ?>
<?php teluro_theme()->get( 'content' )->render(); ?>
<?php get_footer();
