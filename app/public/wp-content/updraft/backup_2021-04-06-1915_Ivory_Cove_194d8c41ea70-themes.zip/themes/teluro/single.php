<?php get_header(); ?>
<?php teluro_theme()->get( 'single' )->render(); ?>
<?php get_footer();
