<?php

teluro_theme()->get( 'sidebar' )->render();
