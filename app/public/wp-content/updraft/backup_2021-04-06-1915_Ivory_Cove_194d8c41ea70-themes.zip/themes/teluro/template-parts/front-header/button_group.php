<div data-colibri-id="7-h27" class="h-x-container style-29 style-local-7-h27 position-relative h-element">
  <div class="h-x-container-inner style-dynamic-7-h27-group style-29-spacing style-local-7-h27-spacing">
    <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
    <?php $component->printButtons(); ?>
  </div>
</div>
