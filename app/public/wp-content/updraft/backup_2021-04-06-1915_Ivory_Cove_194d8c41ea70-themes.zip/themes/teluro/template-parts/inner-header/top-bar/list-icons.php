<div data-colibri-id="10-h19" class="icon-list d-flex justify-content-lg-start justify-content-md-start justify-content-start style-21 style-local-10-h19 position-relative h-element">
  <ul class="ul-list-icon horizontal-on-desktop horizontal-on-tablet horizontal-on-mobile justify-content-lg-start justify-content-md-start justify-content-start">
    <?php $component = \ColibriWP\Theme\View::getData( "component" );  $component->printIcons(); ?>
  </ul>
</div>
