<div data-colibri-id="7-h25" class="h-global-transition-all h-heading style-27 style-local-7-h25 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-heading__outer style-27 style-local-7-h25">
    <h1>
      <?php $component->printTitle(); ?>
    </h1>
  </div>
</div>
