<div data-colibri-id="25-m6" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-548 style-local-25-m6 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-549-outer style-local-25-m7-outer">
      <div data-colibri-id="25-m7" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-549 style-local-25-m7 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="25-m8" class="h-icon style-527 style-local-25-m8 position-relative h-element">
            <span class="h-svg-icon h-icon__icon style-527-icon style-local-25-m8-icon">
              <!--Icon by Font Awesome (https://fontawesome.com)-->
              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="folder-o" viewBox="0 0 1664 1896.0833">
                <path d="M1536 1312V608q0-40-28-68t-68-28H736q-40 0-68-28t-28-68v-64q0-40-28-68t-68-28H224q-40 0-68 28t-28 68v960q0 40 28 68t68 28h1216q40 0 68-28t28-68zm128-704v704q0 92-66 158t-158 66H224q-92 0-158-66T0 1312V352q0-92 66-158t158-66h320q92 0 158 66t66 158v32h672q92 0 158 66t66 158z"></path>
              </svg>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col style-550-outer style-local-25-m9-outer">
      <div data-colibri-id="25-m9" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-550 style-local-25-m9 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="25-m10" class="h-blog-categories style-83 style-local-25-m10 position-relative h-element">
            <div class="h-global-transition-all">
              <?php teluro_post_categories(array (
                'prefix' => '',
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
