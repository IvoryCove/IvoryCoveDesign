<?php

get_header();

teluro_theme()->get( 'main' )->render();

get_footer();
