<?php


namespace ColibriWP\Theme\Customizer\Controls;


use WP_Customize_Cropped_Image_Control;

class CroppedImageControl extends WP_Customize_Cropped_Image_Control {
    use ColibriWPControlsAdapter;
}
