<?php


namespace ColibriWP\Theme\Core;


interface ComponentInterface {

    public function render();

}
