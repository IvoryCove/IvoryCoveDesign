<?php

colibriwp_theme()->get( 'sidebar' )->render(array(
    'id' => 'ecommerce',
    'type' => 'left'
));
