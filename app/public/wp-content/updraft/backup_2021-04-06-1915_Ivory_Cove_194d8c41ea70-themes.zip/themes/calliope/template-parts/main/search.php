<div data-colibri-id="25-m1" class="style-135 style-local-25-m1 position-relative">
  <div data-colibri-component="section" data-colibri-id="25-m2" id="search-results" class="h-section h-section-global-spacing d-flex align-items-lg-center align-items-md-center align-items-center style-136 style-local-25-m2 position-relative">
    <div class="h-section-grid-container h-section-boxed-container">
      <div data-colibri-id="25-m3" class="h-row-container gutters-row-lg-3 gutters-row-md-3 gutters-row-3 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 colibri-dynamic-list style-141 style-local-25-m3 position-relative">
        <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-3 gutters-col-md-3 gutters-col-3 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0 style-141-row style-local-25-m3-row">
          <?php colibriwp_theme()->get('search-loop')->render(); ?>
        </div>
      </div>
      <?php colibriwp_layout_wrapper(array (
        'name' => 'navigation_container',
        'slug' => 'navigation-container-3',
      )); ?>
    </div>
  </div>
</div>
