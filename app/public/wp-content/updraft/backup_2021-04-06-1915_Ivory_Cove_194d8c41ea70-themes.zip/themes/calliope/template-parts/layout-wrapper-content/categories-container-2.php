<div data-colibri-id="19-m8" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-113 style-local-19-m8 position-relative">
  <div class="h-row justify-content-lg-start justify-content-md-start justify-content-start align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-114-outer style-local-19-m9-outer">
      <div data-colibri-id="19-m9" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-114 style-local-19-m9 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="19-m10" class="h-blog-categories style-115 style-local-19-m10 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_categories(array (
                'prefix' => '',
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
